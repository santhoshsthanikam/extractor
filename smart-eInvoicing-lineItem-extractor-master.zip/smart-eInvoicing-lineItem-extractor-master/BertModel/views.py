from django.http import JsonResponse
from rest_framework.views import APIView
import logging
from logging.handlers import TimedRotatingFileHandler
import ast

from .predict import model_predict

tags_vals = ['I-BEG','I-MID', 'O', 'I-AMT', 'I-END','I-LINE','[CLS]', '[SEP]','[PAD]']
MAX_LEN = 122

output1 = 'logs/master.log'
output2 = 'logs/my_app.log'

def myLogger(name):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    logname = name
    handler = TimedRotatingFileHandler(logname, when="midnight", interval=1)
    handler.suffix = "%Y%m%d"
    formatter = logging.Formatter('%(asctime)s — %(invnum)s — %(funcName)s():%(lineno)i — %(levelname)-8s — %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    return logger

def myLogger_Master(name):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    logname = name
    handler = TimedRotatingFileHandler(logname, when="midnight", interval=1)
    handler.suffix = "%Y%m%d"
    formatter = logging.Formatter('%(asctime)s — %(invnum)s — %(funcName)s():%(lineno)i — %(levelname)-8s — %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    return logger

master  = myLogger_Master(output1)
log_ml = myLogger(output2)


class call_model(APIView):

    def get(self,request):
        
        try:

            params =  request.GET.get('sentence')
            inv_num = request.GET.get('inv_num')
            master.info("Recieved API request to extract line items from text", extra={'invnum':inv_num})
            params = ast.literal_eval(params)
            pred_tags = model_predict(params,log_ml, inv_num)
            master.info("Returned NER tags for the requested text", extra={'invnum':inv_num})
            return JsonResponse(pred_tags, safe=False)
        
        except Exception as e:

            master.info("Error occured..." +str(e) , extra={'invnum':inv_num})
            raise e