from keras.models import model_from_json
def model_process():
	json_file = open('./model.json', 'r')
	loaded_model_json = json_file.read()
	json_file.close()
	model = model_from_json(loaded_model_json)
	model.load_weights("./model.h5")
	return model.predict