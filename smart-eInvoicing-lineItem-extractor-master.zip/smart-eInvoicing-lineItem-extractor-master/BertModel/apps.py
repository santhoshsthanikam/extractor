from django.apps import AppConfig
from .model_process import model_process
class BertmodelConfig(AppConfig):
    model = model_process()

    
