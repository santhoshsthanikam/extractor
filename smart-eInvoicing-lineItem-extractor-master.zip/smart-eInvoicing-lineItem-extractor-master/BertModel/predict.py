import numpy as np 
from keras.layers import TimeDistributed,Conv1D,Dense,Embedding,Input,Dropout,LSTM,Bidirectional,MaxPooling1D,Flatten,concatenate
from .preprocess import createMatrices,addCharInformatioin,padding
from keras.models import model_from_json
import pickle
from .apps import BertmodelConfig



def model_predict(sent_word, log_ml, inv_num):
	label2Idx = {}
	word2Idx = {}
	
	with open('./label2Idx.pickle', 'rb') as handle2:
		label2Idx = pickle.load(handle2)
	with open('./filename.pickle', 'rb') as handle:
		word2Idx = pickle.load(handle)
	with open('./char2Idx.pickle', 'rb') as handle:
		char2Idx = pickle.load(handle)
	log_ml.info("Loaded model configuration", extra={'invnum':inv_num})
	testSentences = [sent_word]
	testSentences = addCharInformatioin(testSentences, log_ml, inv_num)
	case2Idx = {'numeric': 0, 'allLower':1, 'allUpper':2, 'initialUpper':3, 'other':4, 'mainly_numeric':5, 'contains_digit': 6, 'PADDING_TOKEN':7}
	caseEmbeddings = np.identity(len(case2Idx), dtype='float32')
	test_set = padding(createMatrices(testSentences, word2Idx,case2Idx,char2Idx,log_ml, inv_num),log_ml,inv_num)
	idx2Label = {v: k for k, v in label2Idx.items()}
	predLabels = []

	for i,data in enumerate(test_set):
		tokens, casing,char = data
		tokens = np.asarray([tokens])
		casing = np.asarray([casing])
		char = np.asarray([char])
		log_ml.info("Passed matrix to the model", extra={'invnum':inv_num})
		pred = BertmodelConfig.model([tokens, casing,char], verbose=False)[0]   
		pred = pred.argmax(axis=-1) #Predict the classes            
		predLabels.append(pred)
		log_ml.info("Model predicted label indices for text", extra={'invnum':inv_num})
	label_correct = []
	for sentence in predLabels:
		label_correct.append([idx2Label[element] for element in sentence])
	log_ml.info("Converted label indices to NER tags", extra={'invnum':inv_num})
	return(label_correct)
