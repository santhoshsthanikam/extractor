from django.shortcuts import render
# from .apps import BertmodelConfig
# Create your views here.
import torch
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
import requests
import torch
import subprocess
# from pytorch_pretrained_bert import BertTokenizer, BertForTokenClassification
from keras.preprocessing.sequence import pad_sequences
import json
from nltk.corpus import stopwords
from nltk import word_tokenize, pos_tag, ne_chunk
from .predict_san import model_predict
import nltk

import ast

tags_vals = ['I-BEG','I-MID', 'O', 'I-AMT', 'I-END','I-LINE','[CLS]', '[SEP]','[PAD]']
MAX_LEN = 122
class call_model(APIView):

    def get(self,request):
        if request.method == 'GET':
            params =  request.GET.get('sentence')
            print(request.GET)
            print((params))
            params = ast.literal_eval(params)
            print(type(params))
            print(len(params))
            pred_tags = model_predict(params)
            return JsonResponse(pred_tags, safe=False)