from django.apps import AppConfig
# import torch
# from pytorch_pretrained_bert import BertForTokenClassification, BertTokenizer

class BertmodelConfig(AppConfig):
    pass
#     model = BertForTokenClassification.from_pretrained("bert-base-cased", num_labels=9)
#     output_model_file = "./models/my_own_model_file.bin"
#     state_dict = torch.load(output_model_file, map_location='cpu')
#     model.load_state_dict(state_dict)
#     model = model.to('cpu')
#     tokenizer = BertTokenizer.from_pretrained('bert-base-cased', do_lower_case=True)
    
    
